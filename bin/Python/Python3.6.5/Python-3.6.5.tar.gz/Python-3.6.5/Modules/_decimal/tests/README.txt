

This directory contains extended tests and a benchmark against decimal.py:

  bench.py  ->  Benchmark for small and large precisions.
  Usage: ../../../python bench.py

  formathelper.py   ->
  randdec.py        ->  Generate test cases for deccheck.py.
  randfloat.py      ->

  deccheck.py  ->  Run extended tests.
  Usage: ../../../python deccheck.py [--short|--medium|--long|--all]


